# reciclakids
Jogo criado para ensinar sobre coleta seletiva a crianças de 5 a 10 anos
