function exemploComponente() {
    return (
        <>
            <div>blah blah blah</div>
        </>
    )
}

export default exemploComponente