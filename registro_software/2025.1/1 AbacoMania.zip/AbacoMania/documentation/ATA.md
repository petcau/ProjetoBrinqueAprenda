<table style="width: 100%;">
  <tr>
    <td style="vertical-align: middle; padding-right: 10px;">
      <h1 style="margin: 0;">Documento da ATA</h1>
    </td>
    <td style="vertical-align: middle; text-align: right;">
      <img src="imagens/logo.png" alt="Logo do Projeto" width="80">
    </td>
  </tr>
</table>

## Data (13/05/25)
### participação
- Emanuel Vitor
- Thiago
- Gustavo Ramon
- Rafael
### o que foi feito
- Discussão de decisão entre a decisão do que será feito no código de função do jogo.
### o que fazer
- Início das atividades de programação

## Data (15/05/25)
### participação
- Gustavo Ramon
- Thiago
- Rafael
- Emanuel vitor
### o que foi feito
- Dados atualizados do andamento do jogo para o trello
### o que fazer
- Design do ábaco ,  a tela principal (unica), funcionamento do jogo e testes
falta criar os css das telas

## Data (22/05/25)
### participação
- Emanuel Vitor
- Thiago
- Gustavo Ramon
- Rafael
- Vitor Thadeu
### o que foi feito
- Organização da lógica do Ábaco, e primeiro funcionamento do jogo em sala de aula.
### o que fazer
- Temporizador pro jogo, telas do CSS, tela de manual do jogo, unir as telas de design com o codigo do jogo,e atribuir sons.

## Data (29/05/25)
### participação
- Gustavo Ramon
- Thiago
- Rafael
- Vitor Thadeu
### o que foi feito
- Finalização do código de funcionamento do jogo inteiro.
- Busca do design das telas de níveis.
### o que fazer
- Implementar o background das telas no código do jogo.
- Realizar os testes e avaliações de funcionamento.