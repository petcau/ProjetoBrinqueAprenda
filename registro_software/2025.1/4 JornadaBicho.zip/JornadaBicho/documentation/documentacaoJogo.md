
<table style="width: 100%;">
  <tr>
    <td style="vertical-align: middle; padding-right: 10px;">
      <h1 style="margin: 0;">Documento do Projeto</h1>
    </td>
    <td style="vertical-align: middle; text-align: right;">
      <img  src="../../Anagrama/documentation/imgs/UNEB-logo.png" width="200">
    </td>
  </tr>
</table>



## Projeto brinque e aprenda.


## Equipe 
- Jadson  – Gestão
- Emanuel G.  – Programador
- Silas – designer
- Joabe  – Gestão
- Felipe – designer
## Descrição

O Jogo desenvolvido pela equipe 4 foi o Arrasta o bicho, que consiste em arrastar um animal para seu respectivo Bioma.

## Objetivo

 O objetivo do jogo consiste em colocar o bicho  no Bioma  em que ele vive. 

## Público Alvo

Crianças em fase inicial de aprendizagem escolar.

## Manual do Jogo
1.Ao abrir nosso site, escolha o jogo "Jornada dos bichos". 

![17490675688203945294271444070569](https://github.com/user-attachments/assets/866cc632-5efd-4b30-a3f8-301c63f964e1)

2. Tela inicial do jogo
 
   ![17484881203953480083007441330882](https://github.com/user-attachments/assets/2b51ff8b-842f-4b93-8a33-79a921057643)
-Logo em seguida você será direcionado para o  nível 1. onde iniciará sua jornada em busca de devolver um animal para o seu Bioma apenas Arrastando-o.

## Cronograma

| Etapa | Período | Status|
|---------------------|-----------------------|------------  |
|criação do código principal  | 08/05/25      | feito |
|ajustes no código  |   15/05/25   | feito|
|criação das imagens e backlog  |17/05/2025 | feito |
|inicio de trabalhos no CSS | 21/05/2025 | feito |
|Últimos ajustes no menu | 29/05/2025 | feito |
