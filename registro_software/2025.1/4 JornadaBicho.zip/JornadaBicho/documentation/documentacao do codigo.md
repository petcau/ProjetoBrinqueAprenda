<table style="width: 100%;">
  <tr>
    <td style="vertical-align: middle; padding-right: 10px;">
      <h1 style="margin: 0;">Documento do Projeto</h1>
    </td>
    <td style="vertical-align: middle; text-align: right;">
      <img  src="../../Anagrama/documentation/imgs/UNEB-logo.png" width="200">
    </td>
  </tr>
</table>

Tecnologia:* React e JSON.
*Lógica do Jogo:* A lógica do jogo consiste em um recurso React de drag and drop (pegar e lagar) para arrastar elementos e poderem ser verificados se está certo ou não.
*Componentes:*
ControlesLevel.jsx

Header.jsx

ListaItens.jsx

ListaZonas.jsx

LogicaGame.jsx

PegarItens.jsx

Resultados.jsx

ZonaColocar.jsx


O background feito pelo figma, usando os emojis disponíveis lá
E o título do jogo foi feito no canva (versão gratuita) usando a fonte "luckiest guy"
